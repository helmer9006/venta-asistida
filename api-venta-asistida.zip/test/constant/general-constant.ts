export const GeneralTestConstant = {
  ONCE: 1,
  ZERO: 0,
};
