-- DropIndex
DROP INDEX "Permission_description_key";

-- DropIndex
DROP INDEX "Permission_path_key";
