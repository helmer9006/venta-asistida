export const environments = {
  dev: '.env',
  qa: '.qa.env',
  prod: '.prod.env',
};
