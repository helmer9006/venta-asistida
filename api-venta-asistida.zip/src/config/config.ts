import { registerAs } from '@nestjs/config';

export default registerAs('config', () => {
  return {
    jwtSecret: process.env.JWT_SECRET,
    exampleProviderGetService: process.env.EXAMPLE_PROVIDER_GET_SERVICE,
    unleash: {
      apiUrl: process.env.UNLEASH_API_URL,
      apiKey: process.env.UNLEASH_API_KEY,
      refreshTime: process.env.UNLEASH_REFRESH_TIME,
    },
    swaggerPassword: process.env.SWAGGER_PASS,
    redisUrl: process.env.REDIS_URL,
  };
});
