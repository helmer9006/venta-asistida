export interface Payload {
  role: string;
  sub: number;
}
