export enum RolesEnum {
  GENERIC_ROL = 'GENERIC_ROL',
  ADMIN = 'ADMIN',
}
