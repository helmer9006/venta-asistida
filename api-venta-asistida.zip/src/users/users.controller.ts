import { Controller, Get, Post, Body, Patch, Param, Delete, Req, Res, HttpStatus } from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { Request, Response } from 'express'
import { GenericResponse } from '@src/shared/models/generic-response.model';
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) { }

  @Post('create')
  create(@Body() createUserDto: CreateUserDto) {
    return this.usersService.create(createUserDto);
  }

  // @Get()
  // findAll() {
  //   return this.usersService.findAll();
  // }

  // @Get(':id')
  // findOne(@Param('id') id: string) {
  //   return this.usersService.findOne(+id);
  // }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateUserDto: UpdateUserDto) {
    return this.usersService.update(+id, updateUserDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.usersService.remove(+id);
  }
  @Get('/signin')
  async signIn(@Req() req: Request, @Res() res: Response) {
    const url = await this.usersService.signIn(res)
    res.redirect(url);
    // res.status(200).json({ data: url, statusCode: 200, message: 'Success' })
  }

  @Get('/signout')
  async signout(@Req() req: Request, @Res() res: Response) {
    const url = await this.usersService.signout()
    res.redirect(url);
    // res.status(200).json({ data: url, statusCode: 200, message: 'Success' })
  }

  // @Get('/redirect')
  // async redirect(@Req() req: Request, @Res() res: Response) {
  //   const { data, message, statusCode } = await this.usersService.redirect(req, res)
  //   res.status(200).json({ data, statusCode, message })
  // }
}
