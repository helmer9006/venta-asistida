import { Injectable, HttpStatus } from '@nestjs/common';
import { CreateUserDto, UpdateUserDto } from './dto';
import { Users } from '@prisma/client'
import { PrismaService } from '@src/prisma/services/prisma.service';
import { ConflictException } from '@src/shared/exceptions/conflict.exception';
import * as msal from '@azure/msal-node';
import { ConfigService } from '@nestjs/config';

const confidentialClientConfig = {
  auth: {
    clientId: process.env.APP_CLIENT_ID,
    authority: process.env.SIGN_UP_SIGN_IN_POLICY_AUTHORITY,
    clientSecret: process.env.APP_CLIENT_SECRET,
    knownAuthorities: [process.env.AUTHORITY_DOMAIN], //This must be an array
    redirectUri: process.env.APP_REDIRECT_URI,
    validateAuthority: false
  },
  system: {
    loggerOptions: {
      loggerCallback(loglevel, message, containsPii) {
        console.log(message);
      },
      piiLoggingEnabled: false,
      logLevel: msal.LogLevel.Verbose,
    }
  }
};

// Initialize MSAL Node
const confidentialClientApplication = new msal.ConfidentialClientApplication(confidentialClientConfig);

const APP_STATES = {
  LOGIN: 'login',
  LOGOUT: 'logout',
  PASSWORD_RESET: 'password_reset',
  EDIT_PROFILE: 'update_profile'
}

interface tokenReq {
  redirectUri: string
  authority?: string;
  code?: string,
  scopes?: []
}

const authCodeRequest: any = {
  redirectUri: confidentialClientConfig.auth.redirectUri,
};

const tokenRequest: any = {
  redirectUri: confidentialClientConfig.auth.redirectUri,
};
@Injectable()
export class UsersService {
  constructor(
    private readonly prismaService: PrismaService,
    private readonly configService: ConfigService
  ) {
  }

  async create(createUserDto: CreateUserDto) {
    try {
      await this.prismaService.users.create({ data: createUserDto })
      return this.prismaService.users.findMany();
    } catch (error) {
      throw new ConflictException({
        status: HttpStatus.CONFLICT.valueOf(),
        details: 'Hay conflictos para crear el usuario',
        error: 'Error creando usuario',
        title: 'Error creando usuario'
      })
    }
    return 'This action adds a new user';
  }

  findAll() {
    console.log("process.env", process.env)
    return this.prismaService.users.findMany();
  }

  findOne(id: number) {
    return `This action returns a #${id} user`;
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return `This action updates a #${id} user`;
  }

  remove(id: number) {
    return `This action removes a #${id} user`;
  }

  async getAuthCode(authority, scopes, state, res) {
    debugger;
    authCodeRequest.authority = authority;
    authCodeRequest.scopes = scopes;
    authCodeRequest.state = state;
    //Each time you fetch Authorization code, update the relevant authority in the tokenRequest configuration
    tokenRequest.authority = authority;
    // request an authorization code to exchange for a token
    return await confidentialClientApplication.getAuthCodeUrl(authCodeRequest)
  }

  signIn(res) {
    //Initiate a Auth Code Flow >> for sign in
    //no scopes passed. openid, profile and offline_access will be used by default.
    const url = this.getAuthCode(this.configService.get('SIGN_UP_SIGN_IN_POLICY_AUTHORITY'), [], APP_STATES.LOGIN, res);
    return url
  }

  signout() {
    return this.configService.get('LOGOUT_ENDPOINT');
  }

  // redirect(req, res) {
  //   //TODO: VALIDAR FLUJO CUANDO YA ESTA LOGUEADO
  //   //determine the reason why the request was sent by checking the state
  //   if (req.query.state === APP_STATES.LOGIN) {
  //     //TODO: Actualizar el uid del usuario validando por email si el usaurio consultado no tiene.
  //     //prepare the request for authentication        
  //     tokenRequest.code = req.query.code;
  //     confidentialClientApplication.acquireTokenByCode(tokenRequest).then((response) => {
  //       // req.session.sessionParams = { user: response.account, idToken: response.idToken };
  //       console.log("\nAuthToken: \n" + JSON.stringify(response));
  //       return { data: { user: response.account, idToken: response.idToken }, message: 'Success', statusCode: 200 };
  //       // res.render('signin', { showSignInButton: false, givenName: response.account.idTokenClaims.given_name });
  //     }).catch((error) => {
  //       throw new ConflictException({
  //         status: HttpStatus.INTERNAL_SERVER_ERROR.valueOf(),
  //         details: `ErrorAtLogin: ${error}`,
  //         error: 'Error login usuario',
  //         title: 'Error login usuario'
  //       })
  //     });
  //   } else if (req.query.state === APP_STATES.PASSWORD_RESET) {
  //     //If the query string has a error param
  //     if (req.query.error) {
  //       //and if the error_description contains AADB2C90091 error code
  //       //Means user selected the Cancel button on the password reset experience 
  //       if (JSON.stringify(req.query.error_description).includes('AADB2C90091')) {
  //         //Send the user home with some message
  //         //But always check if your session still exists
  //         // res.render('signin', { showSignInButton: false, givenName: req.session.sessionParams.user.idTokenClaims.given_name, message: 'User has cancelled the operation' });
  //         return { data: null, message: 'Usuario ha cancelado la operación', statusCode: 200 };
  //       }
  //     } else {
  //       return { data: null, message: 'Success', statusCode: 200 };
  //       // res.render('signin', { showSignInButton: false, givenName: req.session.sessionParams.user.idTokenClaims.given_name });
  //     }

  //   } else if (req.query.state === APP_STATES.EDIT_PROFILE) {

  //     tokenRequest.scopes = [];
  //     tokenRequest.code = req.query.code;

  //     //Request token with claims, including the name that was updated.
  //     confidentialClientApplication.acquireTokenByCode(tokenRequest).then((response) => {
  //       req.session.sessionParams = { user: response.account, idToken: response.idToken };
  //       console.log("\AuthToken: \n" + JSON.stringify(response));
  //       //TODO: Actualizar el uid del usuario validando por email si el usaurio consultado no tiene.
  //       return { data: { user: response.account, idToken: response.idToken }, message: 'Success', statusCode: 200 };
  //       // res.render('signin', { showSignInButton: false, givenName: response.account.idTokenClaims.given_name });
  //     }).catch((error) => {
  //       //Handle error
  //       throw new ConflictException({
  //         status: HttpStatus.INTERNAL_SERVER_ERROR.valueOf(),
  //         details: `Error login usuario, ${error}`,
  //         error: 'Error login usuario',
  //         title: 'Error login usuario'
  //       })
  //     });
  //   } else {
  //     throw new ConflictException({
  //       status: HttpStatus.INTERNAL_SERVER_ERROR.valueOf(),
  //       details: `We do not recognize this response!`,
  //       error: 'Error login usuario',
  //       title: 'Error login usuario'
  //     })
  //     // res.status(500).send('We do not recognize this response!');
  //   }
  // }
}
