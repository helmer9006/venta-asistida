import { IsUUID, IsString, IsBoolean, IsOptional, IsDate } from "class-validator";

export class CreateUserDto {
    @IsString()
    // @IsUUID() TODO:  validar el tipo de uid que llega de microsoft
    @IsOptional()
    uid: string;

    @IsString()
    name: string;

    @IsString()
    lastname: string;

    @IsString()
    email: string;

    // @IsBoolean()
    // isActive: boolean;

    @IsOptional()
    roleId: number

    @IsDate()
    updatedAt: Date
}
